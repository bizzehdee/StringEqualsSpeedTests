﻿using System.Diagnostics;

namespace stringTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var testCount = 10000000;

            var stringOneCased = "Hello, World!";
            var stringTwoLower = "hello, world!";
            var stringTwoUpper = "HELLO, WORLD!";

            var stopwatch = new Stopwatch();

            var count = 0;

            Console.WriteLine($"Testing: ToLowerInvariant() {testCount} times");
            Console.WriteLine("==================");

            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < testCount; i++)
            {
                if (stringOneCased.ToLowerInvariant() == stringTwoLower) { count++; }
            }
            stopwatch.Stop();
            Console.WriteLine("Time elapsed (ms): {0}", stopwatch.Elapsed.TotalMilliseconds);
            Console.WriteLine();
            Console.WriteLine();


            count = 0;
            Console.WriteLine($"Testing: ToUpperInvariant() {testCount} times");
            Console.WriteLine("==================");

            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < testCount; i++)
            {
                if (stringOneCased.ToUpperInvariant() == stringTwoUpper) { count++; }
            }
            stopwatch.Stop();
            Console.WriteLine("Time elapsed (ms): {0}", stopwatch.Elapsed.TotalMilliseconds);
            Console.WriteLine();
            Console.WriteLine();

            count = 0;
            Console.WriteLine($"Testing: DOUBLE ToLowerInvariant() {testCount} times");
            Console.WriteLine("==================");

            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < testCount; i++)
            {
                if (stringOneCased.ToLowerInvariant() == stringTwoUpper.ToLowerInvariant()) { count++; }
            }
            stopwatch.Stop();
            Console.WriteLine("Time elapsed (ms): {0}", stopwatch.Elapsed.TotalMilliseconds);
            Console.WriteLine();
            Console.WriteLine();


            count = 0;
            Console.WriteLine($"Testing: InvariantCultureIgnoreCase {testCount} times");
            Console.WriteLine("==================");

            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < testCount; i++)
            {
                if (stringOneCased.Equals(stringTwoLower, StringComparison.InvariantCultureIgnoreCase)) { count++; }
            }
            stopwatch.Stop();
            Console.WriteLine("Time elapsed (ms): {0}", stopwatch.Elapsed.TotalMilliseconds);
            Console.WriteLine();
            Console.WriteLine();

            count = 0;
            Console.WriteLine($"Testing: CurrentCultureIgnoreCase {testCount} times");
            Console.WriteLine("==================");

            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < testCount; i++)
            {
                if (stringOneCased.Equals(stringTwoLower, StringComparison.CurrentCultureIgnoreCase)) { count++; }
            }
            stopwatch.Stop();
            Console.WriteLine("Time elapsed (ms): {0}", stopwatch.Elapsed.TotalMilliseconds);
            Console.WriteLine();
            Console.WriteLine();

            count = 0;
            Console.WriteLine($"Testing: OrdinalIgnoreCase {testCount} times");
            Console.WriteLine("==================");

            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < testCount; i++)
            {
                if (stringOneCased.Equals(stringTwoLower, StringComparison.OrdinalIgnoreCase)) { count++; }
            }
            stopwatch.Stop();
            Console.WriteLine("Time elapsed (ms): {0}", stopwatch.Elapsed.TotalMilliseconds);
        }
    }
}
